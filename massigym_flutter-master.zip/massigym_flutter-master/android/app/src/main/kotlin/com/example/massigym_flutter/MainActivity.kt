package com.example.massigym

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
